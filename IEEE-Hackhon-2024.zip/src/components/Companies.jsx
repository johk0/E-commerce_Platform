import img1 from '../assets/fa-brands-1.png'
import img2 from '../assets/fa-brands-2.png'
import img3 from '../assets/fa-brands-3.png'
import img4 from '../assets/fa-brands-4.png'
import img5 from '../assets/fa-brands-5.png'
import img6 from '../assets/fa-brands-6.svg'

export default function Companies(){
    return(
        <div className="composlide">
        <div className="track">
    <img src={img1} alt="" />
    <img src={img2} alt="" />
    <img src={img3} alt="" />
    <img src={img4} alt="" />
    <img src={img5} alt="" />
    <img src={img6} alt="" />
    <img src={img1} alt="" />
    <img src={img2} alt="" />
    <img src={img3} alt="" />
    <img src={img4} alt="" />
    <img src={img5} alt="" />
    <img src={img6} alt="" />
    <img src={img1} alt="" />
    <img src={img2} alt="" />
    <img src={img3} alt="" />
    </div>
    </div>   
    )
}