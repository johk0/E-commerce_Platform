// export const API = {
// 	register: "https://samiramustafa.pythonanywhere.com/users/register/",
// 	login: "https://samiramustafa.pythonanywhere.com/users/login/",
// 	products: "https://samiramustafa.pythonanywhere.com/users/products/",
// 	categories: "https://samiramustafa.pythonanywhere.com/api/categories/",
// };
export const API = {
	register: "https://dummyjson.com/users/add",
	login: "https://dummyjson.com/user/login",
	products: "https://dummyjson.com/products",
	categories: "https://samiramustafa.pythonanywhere.com/api/categories/",
};
